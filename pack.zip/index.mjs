import { Fernet } from 'fernet-nodejs';

export const handler = async (event) => {
    // Get query string parameters from event object
    const queryStringParameters = event.queryStringParameters;

    // Get data and parameters to decrypt
    let requestCryptData = queryStringParameters.userData;
    let cryptoKey = process.env.MY_VAR || "qltrY4rh25bHsAgGSqgh3EBhrHgELCtH4lrNzADxVK8";

    // create new Fernet instance
    const f = new Fernet(cryptoKey);

    // decrypt token and get message
    const plainText = f.decrypt(requestCryptData);
    
    const response = {
        statusCode: 200,
        body: JSON.stringify(plainText),
    };
    return response;
  };